Turista GO - Edição Brasília
Projeto interativo desenvolvido para a matéria de Novas Tecnologias da Universidade Católica de Brasília.

<p text-align:justify>"Turista GO" é um jogo de exploração feito em Pygame e conectado a uma aplicação web em Flask. O objetivo é navegar por um mapa de Brasília e "visitar" os pontos turísticos. Para validar uma visita, o jogador escaneia um QR Code com o celular e envia uma foto do local, que é autenticada por um sistema de reconhecimento de imagem em OpenCV. O progresso de cada jogador fica salvo em seu perfil no site.</p>

Tecnologias: Python, Flask, Pygame, OpenCV, e Pandas.

Equipe de Desenvolvimento
Ana Eduarda Raposo Medeiros - uc23200232
<br>
Anette Stefany Villalba Palomino - uc23200441
<br>
Agatha Karenne De Andrade Machado - uc23200247
<br>
Brunno Calado Cavalcante - uc23101210
<br>
Clarice Christine Soares Viana - uc23200796
<br>
Débora Cristina Silva Ferreira - uc23200792
<br>
Disciplina
<br>


Matéria: Novas Tecnologias
<br>
Professor: Adam Smith
